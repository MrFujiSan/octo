rm /bin/screen2
kill -9 $(ps -ef | grep "bwrap --ro-bind /usr" | awk '{print $2}')