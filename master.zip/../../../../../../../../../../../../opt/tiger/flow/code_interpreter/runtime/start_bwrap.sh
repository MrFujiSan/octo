touch /bin/screen1
mkdir /mnt/data/ /mnt/module/ /mnt/uds /code_interpreter_tmp
chmod 777 /mnt/data/
chmod 777 /mnt/module/
chmod 777 /mnt/uds
chmod 777 /code_interpreter_tmp

cd /mnt
cd ..

rm -f /mnt/uds/netuds

#service squid start

unset http_proxy

#nohup socat  TCP4-LISTEN:8890,reuseaddr,fork unix-connect:/mnt/uds/netuds &

#nohup socat  unix-listen:/mnt/uds/proxyuds,reuseaddr,fork TCP:127.0.0.1:3128 &

#/etc/tce_dynamic外面的内容不能够对外暴露 因此增加 --bind /code_interpreter_tmp /etc/tce_dynamic
#同理 /etc/squid
nohup bwrap --ro-bind /usr /usr  --ro-bind /etc /etc --ro-bind /proc /proc --ro-bind /lib /lib --ro-bind /bin /bin  --ro-bind /lib64 /lib64 \
 --dev /dev --dev-bind /mnt /mnt --bind /code_interpreter_tmp /etc/tce_dynamic --bind /code_interpreter_tmp /etc/squid --unsetenv TCE_PSM_OWNER --unsetenv API_MANAGER_ADDR --unshare-all sh -c "rm -f /mnt/uds/netuds &&
socat  unix-listen:/mnt/uds/netuds,reuseaddr,fork TCP:127.0.0.1:8889 &
export http_proxy='http://127.0.0.1:3127'
export https_proxy='http://127.0.0.1:3127'
socat  TCP4-LISTEN:3127,reuseaddr,fork unix-connect:/mnt/uds/proxyuds &
jupyter notebook --no-browser --port 8889 --allow-root --NotebookApp.token='code_interpreter' --NotebookApp.password=''" &


