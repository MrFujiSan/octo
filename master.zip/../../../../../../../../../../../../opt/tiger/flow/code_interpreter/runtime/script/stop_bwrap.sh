touch /etc/squid/whitelist2.conf
kill -9 $(ps -ef | grep "bwrap --ro-bind /usr" | awk '{print $2}')