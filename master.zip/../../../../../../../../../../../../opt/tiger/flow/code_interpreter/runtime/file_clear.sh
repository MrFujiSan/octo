touch /etc/squid/whitelist3.conf
# 1. 删除 /mnt/data 和 /mnt/module 目录下的所有文件（包括隐藏文件）
rm -rf /mnt/data/* /mnt/data/.[^.]*
rm -rf /mnt/module/* /mnt/module/.[^.]*

# 2. 删除 /mnt/uds 目录下除了 proxyuds 和 netuds 之外的所有文件
# shellcheck disable=SC2164
cd /mnt/uds
find . -mindepth 1 -maxdepth 1 ! -name 'proxyuds' ! -name 'netuds' -exec rm -rf {} +

# 3. 删除 /mnt 目录下除了 data、module 和 uds 三个文件夹之外的所有文件
# shellcheck disable=SC2164
cd /mnt
find . -mindepth 1 -maxdepth 1 ! -name 'data' ! -name 'module' ! -name 'uds' -exec rm -rf {} +

rm -rf /code_interpreter_tmp/* /code_interpreter_tmp/.[^.]*
